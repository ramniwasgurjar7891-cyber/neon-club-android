package com.neonclub.demo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

public class RoundService extends Service {
    private static final String CHANNEL_ID = "neon_demo_running";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private PowerManager.WakeLock wakeLock;
    private int seconds = 60;

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            seconds--;
            if (seconds <= 0) seconds = 60;
            updateNotification();
            handler.postDelayed(this, 1000);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "NeonClub:DemoTimer");
        wakeLock.setReferenceCounted(false);
        try { wakeLock.acquire(10 * 60 * 60 * 1000L); } catch (Exception ignored) {}
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        startForeground(7, buildNotification());
        handler.removeCallbacks(ticker);
        handler.post(ticker);
        return START_STICKY;
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Neon Club demo status", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows that the local demo timer service is running.");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, CHANNEL_ID) : new Notification.Builder(this);
        return b.setContentTitle("Neon Club Demo is running")
            .setContentText("Background demo timer: " + seconds + "s left in this cycle")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi).setOngoing(true).build();
    }

    private void updateNotification() {
        ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7, buildNotification());
    }

    @Override public void onDestroy() {
        handler.removeCallbacks(ticker);
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
