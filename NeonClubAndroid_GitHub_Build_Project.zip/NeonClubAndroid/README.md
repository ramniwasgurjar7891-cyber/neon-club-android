# Neon Club Android Demo

This repository contains a local entertainment-only WebView demo and an Android foreground-service sample.

## Build on GitHub mobile
1. Upload all files and folders from this project ZIP to the repository root (not the ZIP file itself).
2. Commit the upload to the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build Neon Club Demo APK** and tap **Run workflow** (or wait for the push build).
5. When complete, open the workflow run and download the `Neon-Club-Demo-debug-apk` artifact.

## Notes
- This is a demo app with simulated outcomes and virtual coins only. It does not connect to a real-money game or payment service.
- The foreground service displays a persistent notification and runs a simple local timer while Android allows it.
- Android may stop services due to force-stop, battery policies, manufacturer restrictions, or permission settings. Continuous operation cannot be guaranteed.
- The WebView page itself may be paused by Android while the screen is off; the service timer is separate and does not guarantee that web content refreshes in the background.
- This is a debug APK, not a Play Store release-signed APK.
